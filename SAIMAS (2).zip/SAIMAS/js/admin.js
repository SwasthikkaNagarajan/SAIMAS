alert("admin.js LOADED");

// ---------------- LOGIN SYSTEM ----------------

document.addEventListener("DOMContentLoaded", () => {

    // LOGIN PAGE LOGIC
    const loginForm = document.getElementById("loginForm");

    if (loginForm) {
        loginForm.addEventListener("submit", function (e) {
            e.preventDefault();

            const role = document.getElementById("role").value;

            // Save login info
            localStorage.setItem("loggedIn", "true");
            localStorage.setItem("role", role);

            // Redirect based on role
            if (role === "admin") {
                window.location.href = "admin-dashboard.html";
            } else if (role === "faculty") {
                window.location.href = "faculty-dashboard.html";
            } else if (role === "student") {
                window.location.href = "student-dashboard.html";
            }
        });
    }

});
// ---------------- PAGE PROTECTION ----------------

document.addEventListener("DOMContentLoaded", () => {
    const isLoginPage = window.location.pathname.includes("login.html");

    if (!isLoginPage) {
        const loggedIn = localStorage.getItem("loggedIn");
        const role = localStorage.getItem("role");

        if (!loggedIn || !role) {
            window.location.href = "login.html";
        }
    }
});

// Runs after the page loads
document.addEventListener("DOMContentLoaded", () => {

    // Dashboard dummy data (later from backend)
    const students = document.getElementById("studentsCount");
    const faculty = document.getElementById("facultyCount");
    const subjects = document.getElementById("subjectsCount");

    if (students && faculty && subjects) {
        students.innerText = 120;
        faculty.innerText = 15;
        subjects.innerText = 25;
    }

});
const users = [
    { name: "John", email: "john@gmail.com", role: "Student" },
    { name: "Smith", email: "smith@gmail.com", role: "Faculty" }
];

const table = document.getElementById("userTable");

function loadUsers() {
    table.innerHTML = "";
    users.forEach((user, index) => {
        table.innerHTML += `
            <tr>
                <td>${user.name}</td>
                <td>${user.email}</td>
                <td>${user.role}</td>
                <td>
                    <button onclick="deleteUser(${index})">Delete</button>
                </td>
            </tr>
        `;
    });
}

function deleteUser(index) {
    users.splice(index, 1);
    loadUsers();
}

loadUsers();
// ---------------- SUBJECT MANAGEMENT ----------------

const subjects = [
    { name: "Mathematics", code: "MATH101", faculty: "Not Assigned" },
    { name: "Computer Science", code: "CS102", faculty: "Not Assigned" }
];

const subjectTable = document.getElementById("subjectTable");

function loadSubjects() {
    if (!subjectTable) return;

    subjectTable.innerHTML = "";
    subjects.forEach((sub, index) => {
        subjectTable.innerHTML += `
            <tr>
                <td>${sub.name}</td>
                <td>${sub.code}</td>
                <td>${sub.faculty}</td>
                <td>
                    <button onclick="deleteSubject(${index})">Delete</button>
                </td>
            </tr>
        `;
    });
}

function deleteSubject(index) {
    subjects.splice(index, 1);
    loadSubjects();
}

const subjectForm = document.getElementById("subjectForm");
if (subjectForm) {
    subjectForm.addEventListener("submit", function (e) {
        e.preventDefault();

        const name = document.getElementById("subjectName").value;
        const code = document.getElementById("subjectCode").value;

        subjects.push({
            name: name,
            code: code,
            faculty: "Not Assigned"
        });

        subjectForm.reset();
        loadSubjects();
    });
}

loadSubjects();
// ---------------- ACADEMIC REPORTS ----------------

document.addEventListener("DOMContentLoaded", () => {
    const reportTable = document.getElementById("reportTable");
    const reportForm = document.getElementById("reportFilterForm");

    if (!reportTable) return; // not on reports page

    // Dummy report data (later from backend)
    const reports = [
        { name: "John", subject: "Mathematics", attendance: 85, marks: 18 },
        { name: "John", subject: "Computer Science", attendance: 90, marks: 20 },
        { name: "Smith", subject: "Mathematics", attendance: 75, marks: 15 }
    ];

    function loadReports(data) {
        reportTable.innerHTML = "";
        data.forEach(r => {
            reportTable.innerHTML += `
                <tr>
                    <td>${r.name}</td>
                    <td>${r.subject}</td>
                    <td>${r.attendance}</td>
                    <td>${r.marks}</td>
                </tr>
            `;
        });
    }

    if (reportForm) {
        reportForm.addEventListener("submit", function (e) {
            e.preventDefault();

            const type = document.getElementById("filterType").value;
            const value = document.getElementById("filterValue").value.toLowerCase();

            const filtered = reports.filter(r =>
                type === "student"
                    ? r.name.toLowerCase().includes(value)
                    : r.subject.toLowerCase().includes(value)
            );

            loadReports(filtered);
        });
    }

    loadReports(reports);
});
// ---------------- FACULTY MODULE ----------------

document.addEventListener("DOMContentLoaded", () => {
    const table = document.getElementById("facultyTable");
    const attendanceForm = document.getElementById("attendanceForm");
    const marksForm = document.getElementById("marksForm");

    if (!table) return; // not faculty page

    const records = [];

    function loadRecords() {
        table.innerHTML = "";
        records.forEach(r => {
            table.innerHTML += `
                <tr>
                    <td>${r.student}</td>
                    <td>${r.subject}</td>
                    <td>${r.attendance}</td>
                    <td>${r.marks}</td>
                </tr>
            `;
        });
    }

    attendanceForm.addEventListener("submit", e => {
        e.preventDefault();
        const inputs = attendanceForm.querySelectorAll("input, select");

        records.push({
            student: inputs[0].value,
            subject: inputs[1].value,
            attendance: inputs[2].value,
            marks: "-"
        });

        attendanceForm.reset();
        loadRecords();
    });

    marksForm.addEventListener("submit", e => {
        e.preventDefault();
        const inputs = marksForm.querySelectorAll("input");

        records.push({
            student: inputs[0].value,
            subject: inputs[1].value,
            attendance: "-",
            marks: inputs[2].value
        });

        marksForm.reset();
        loadRecords();
    });
});
// ---------------- STUDENT MODULE ----------------

document.addEventListener("DOMContentLoaded", () => {
    const attendanceTable = document.getElementById("attendanceTable");
    const marksTable = document.getElementById("marksTable");

    if (!attendanceTable || !marksTable) return; // not student page

    // Dummy data (later from backend)
    const attendanceData = [
        { subject: "Mathematics", attendance: 85 },
        { subject: "Computer Science", attendance: 90 },
        { subject: "Physics", attendance: 78 }
    ];

    const marksData = [
        { subject: "Mathematics", marks: 18 },
        { subject: "Computer Science", marks: 20 },
        { subject: "Physics", marks: 16 }
    ];

    attendanceData.forEach(a => {
        attendanceTable.innerHTML += `
            <tr>
                <td>${a.subject}</td>
                <td>${a.attendance}</td>
            </tr>
        `;
    });

    marksData.forEach(m => {
        marksTable.innerHTML += `
            <tr>
                <td>${m.subject}</td>
                <td>${m.marks}</td>
            </tr>
        `;
    });
});
// ================= LOGOUT =================
document.addEventListener("DOMContentLoaded", () => {
    const logoutBtn = document.querySelector(".logout-btn");

    if (!logoutBtn) return;

    logoutBtn.addEventListener("click", () => {
        localStorage.clear();

        // Absolute path (Live Server safe)
        window.location.replace("/login.html");
    });
});
