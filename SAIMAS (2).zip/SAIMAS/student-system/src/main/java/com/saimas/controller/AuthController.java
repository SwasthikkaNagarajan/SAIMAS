package com.saimas.studentsystem.controller;

import com.saimas.studentsystem.model.User;
import com.saimas.studentsystem.service.UserService;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    // LOGIN API
    @PostMapping("/login")
    public User login(@RequestBody User request) {
        return userService.login(request.getEmail(), request.getPassword());
    }

    // REGISTER (optional for testing)
    @PostMapping("/register")
    public User register(@RequestBody User user) {
        return userService.saveUser(user);
    }
}
